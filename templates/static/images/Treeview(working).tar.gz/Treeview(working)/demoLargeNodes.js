//
// Copyright (c) 2006 by Conor O'Mahony.
// For enquiries, please email GubuSoft@GubuSoft.com.
// Please keep all copyright notices below.
// Original author of TreeView script is Marcelino Martins.
//
// This document includes the TreeView script.
// The TreeView script can be found at http://www.TreeView.net.
// The script is Copyright (c) 2006 by Conor O'Mahony.
//

USETEXTLINKS = 1  
STARTALLOPEN = 0
HIGHLIGHT = 1
PRESERVESTATE = 1
GLOBALTARGET="R"


foldersTree = gFld("Pritam", "demoLargeRightFrame.html")
Private = gFld("Private", "javascript:parent.op()")
Private.xID = "Private"
Circles = gFld("Circles", "javascript:parent.op()")
Circles.xID = "Circles"
Public = gFld("Public", "javascript:parent.op()")
Public.xID = "Public"
foldersTree.addChildren([Private,Circles,Public])

foldersTree.treeID = "L1" 
foldersTree.xID = "bigtree"

