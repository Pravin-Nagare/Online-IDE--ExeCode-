import tornado.web
import tornado.httpserver
import tornado.ioloop
import os



class Main(tornado.web.RequestHandler):

	def get(self):
		uname="pritam"		
		entries=[]
		for root,dir1,files in os.path.walk(os.getcwd()):
			for f in files:
				entries.append(f)
			
		for e in entries:
			print e

	

if __name__ == "__main__":
	application = tornado.web.Application([
		(r"/",Main),
		],debug=True, cookie_secret="61oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=")
	http_server = tornado.httpserver.HTTPServer(application)
	http_server.listen(8888)
	tornado.ioloop.IOLoop.instance().start()
