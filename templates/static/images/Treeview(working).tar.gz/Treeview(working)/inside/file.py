#include<stdio.h>
main()
{
   printf("hello from \"ExeCode\"");
}