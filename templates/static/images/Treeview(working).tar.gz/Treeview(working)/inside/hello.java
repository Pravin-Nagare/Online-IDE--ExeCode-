class hello
{
public static void main(string args[])
{
System.println("hello from java");
}
}